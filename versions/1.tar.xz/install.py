run("cp /tmp/ramsay/ramsay.py /py/ramsay.py")
